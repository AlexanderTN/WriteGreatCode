#include <stdio.h>
int main( int argc, char **argv )
{
	printf( "\n\n\n\n", argc, argv );
	return 0;
}
